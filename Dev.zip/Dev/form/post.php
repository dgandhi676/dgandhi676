 <?php 
 echo $_POST["fname"]; 
 echo "</br>";
 echo $_POST["lname"]; 
 echo "</br>";
 echo $_POST["gender"];
 echo "</br>";
 echo $_POST["city"];
 echo "</br>";
print_r($_POST["hobbies"]);
 echo "</br>";
 ?>
