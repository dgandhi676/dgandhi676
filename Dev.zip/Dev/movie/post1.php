<?php
echo $_POST["movie_name"]; 
echo "</br>";
echo $_POST["movie_description"]; 
echo "</br>";
print_r ($_POST["genre[]"]);
echo "</br>";
echo $_POST["adult"];
echo "</br>";
echo $_POST["watched"];
echo "</br>";
 ?>
