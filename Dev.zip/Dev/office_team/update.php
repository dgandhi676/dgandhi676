<?php
include 'db_connect.php';
error_reporting(0);
$id = $_GET['id'];
// print_r($id);
$sql = "SELECT * FROM employee WHERE ot_id = ".$id;
$result = mysqli_query($conn,$sql);
$fet = $result ->fetch_array();
// print_r($fet);
$data = $fet['ot_completed_5_years'];
$data1 = explode(",",$data);
// print_r($data1);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Member</title>

    <script>
        function validateform() {
            let a = document.forms['teamform']['fname'].value;
            if(a == "")
            {
                alert("Employee First Name is Empty!!");
                return false;
            }
            let b = document.forms['teamform']['lname'].value;
            if (b == "")
            {
                alert("Employee Last Name is Empty!!");
                return false;
            }
            let c = document.getElementById("empimg");
            let j = c.value;
            let allowesEx = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
            if (!allowesEx.test(j))
            {
                alert("Please Upload file having extensions .jpeg/.jpg/.png/.gif only. !!");
                c.value = '';
                return false;
            }
            let d = document.forms['teamform']['email'].value;
            if (d == "")
            {
                alert("Please Enter Your E-Mail!!!");
                return false;
            }
            let e = document.getElementById("Male").checked;
            let f = document.getElementById("Female").checked;
            if(!e && !f)
            {
                alert("Select a Gender");
                return false;
            }
            let g = document.querySelectorAll('input[name="complete[]"]:checked');
            if(g.length === 0)
            {
                alert("Select Atleast One Option");
                return false;
            }
            let h = document.forms["teamform"]["profiledes"].value;
            if(h == "")
            {
                alert("Please Enter Profile Description!!!");
                return false;
            }
        }
    </script>
</head>
<body style="background-color: antiquewhite; text-align: center; ">
    <form action="" method="post" id="teamform" enctype="multipart/form-data" onsubmit="return validateform()">
        <h1>Update Member</h1>
        <br>

        <label for="fname">First Name: </label>
        <input type="text" name="fname" id="fname" value="<?php echo $fet['ot_firstname']; ?>">
        
        <br>
        <br>

        <label for="lname">Last Name:</label>
        <input type="text" name="lname" id="lname" value="<?php echo $fet['ot_lastname']; ?>">

        <br>
        <br>

        <label>Preview: </label>
        <img src="<?php echo $fet['ot_image'];?>" height="100px" width="100px">

        <br>
        <br>

        <label for="empimg">Image: </label>
        <input type="file" name="empimg" id="empimg" value="<?php echo $fet['ot_image'];?>">

        <br>
        <br>

        <label for="email">E-Mail: </label>
        <input type="email" name="email" id="email" value="<?php echo $fet['ot_email'];?>">

        <br>
        <br>

        <label for="gender" value="" > Gender: </label>

        <input type="radio" name="gender" id="Male" value="Male"  
        <?php if($fet['ot_gender'] == "Male"){echo "checked";}?>>Male


        <input type="radio" name="gender" id="Female" value="Female"
        <?php if($fet['ot_gender']=="Female"){echo "checked";}?>>Female

        <br>
        <br>

        <label for="complete" name="complete" id="complete">5 Years Completed: </label>

            <input type="checkbox" name="complete[]" value="Yes" id="Yes" value="Yes" 
        <?php if(in_array("Yes",$data1)){echo "checked";}?>> Yes

            <input type="checkbox" name="complete[]" value="No" id="No" value="No" 
        <?php if(in_array("No",$data1)){echo "checked";}?>> No

        <br>
        <br>

        <label for="profiledes">Profile Description:</label>
        <textarea name="profiledes" id="profiledes" cols="30" rows="10"><?php echo $fet['ot_profile'];?></textarea>

        <br>
        <br>

        <button type="submit" name="update" value="update"> Update Details </button>
    </form>

    <?php
    if(isset($_POST['update'])){

        $fname = $_POST['fname'];
        $lname = $_POST['lname'];



        $imgname = $_FILES['empimg']['name'];
        $tempname = $_FILES['empimg']['tmp_name'];
        $folder1 = "emp-image/".$imgname;
        move_uploaded_file($tempname, $folder1);
        
        if (file_exists($folder1)) {
        $path_parts = pathinfo($folder1);
        if(isset($path_parts['extension'])) {
            $timestamp = time();
            $new_filename = $path_parts['filename'] . '_' . $timestamp . '.' . $path_parts['extension'];
            $new_folder1 = "emp-image/" . $new_filename;
            if(rename($folder1, $new_folder1)) {
                $folder1 = $new_folder1;
            }
        }
    }


    $email = $_POST['email'];
    $gender = $_POST['gender'];


    $complete = $_POST['complete'];
    if(!empty($complete)){
        $complete5 = implode(",",$complete);
    }
    
    $profiledes = $_POST['profiledes'];

    $sqli = "UPDATE employee SET ot_firstname='$fname', ot_lastname='$lname', ot_image='$folder1', ot_email='$email', ot_gender='$gender', ot_completed_5_years='$complete5', ot_profile='$profiledes' WHERE ot_id='$id' ";

    if(mysqli_query($conn,$sqli))
    {
        echo "Record Updated";
        header('location:empdata.php?msg= New Record Added');

    }
    else
    {
        echo "error: failed to Update".mysqli_error($conn);
    }
    }
    ?>
    <br>
    <a href="empdata.php"><button> Employee List </button></a>
</body>
</html>