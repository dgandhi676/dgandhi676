<?php
include 'db_connect.php';
$sql = "SELECT * FROM employee";
$run1 = mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Database</title>
</head>
<body style="background-color: aquamarine; text-align:center; margin-left: 150px; margin-right: 150px; ">
    <table border="3" cellspacing="4" cellpading="5" style="text-align: center;">
    <br>
    <th colspan="10">
        <br>
        <br>
        <h2>Employee Record</h2>
        <a href="index.php">
        <button>
            Add Employee
        </button>
        </a>
        <br>
        <br>
    </th>
    <tr class="heading">
        <th>
            ID
        </th>
        <th>
            First Name
        </th>
        <th>
            Last Name
        </th>
        <th>
            Image
        </th>
        <th>
            E-Mail
        </th>
        <th>
            Gender
        </th>
        <th>
            Completed 5 Years
        </th>
        <th>
            Profile Description
        </th>
        <th colspan="2">
            Action
        </th>
        
    </tr>
</tr>
    <tr colspan="9">
        <?php 
        if ($num1 = mysqli_num_rows($run1)>0) {}
        else{echo "Sorry No Records Found!!!!";}
        ?>
    </tr>
    <?php
    $i=1;
    if ($num1 = mysqli_num_rows($run1)>0) {
        while ($result = mysqli_fetch_assoc($run1)){
            echo "
            <tr>
            <td>".$result['ot_id']."</td>
            <td>".$result['ot_firstname']."</td>
            <td>".$result['ot_lastname']."</td>
            <td><img src='".$result['ot_image']."' height='75px' width='75px'></td>
            <td>".$result['ot_email']."</td>
            <td>".$result['ot_gender']."</td>
            <td>".$result['ot_completed_5_years']."</td>
            <td>".$result['ot_profile']."</td>
            
            <td><button><a href = 'update.php?id=".$result['ot_id']."'>Update
            </a></button></td> 

                    <td><button><a href = 'delete.php?id=".$result['ot_id']."' id='btn'>DELETE</a></button></td>
            </tr>";
        }
    }
    ?>
</table>
</body>
</html>